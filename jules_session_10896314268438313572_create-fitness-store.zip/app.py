from flask import Flask, render_template, request

app = Flask(__name__)

# Shipping Cost
SHIPPING_COST = 4.99

# Dummy product data
products = [
    {"id": 1, "name": "Dumbbell Set (5kg)", "price": 29.99, "description": "Perfect voor krachttraining thuis."},
    {"id": 2, "name": "Yogamat (eco-vriendelijk)", "price": 24.50, "description": "Comfortabel en anti-slip voor je yoga-sessies."},
    {"id": 3, "name": "Weerstandsbanden (set van 3)", "price": 14.95, "description": "Ideaal voor warming-ups en revalidatie."}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/products')
def products_page():
    return render_template('products.html', products=products)

@app.route('/checkout/<int:product_id>')
def checkout(product_id):
    product = next((p for p in products if p['id'] == product_id), None)
    if product:
        total_price = product['price'] + SHIPPING_COST
        return render_template('checkout.html', product=product, shipping_cost=SHIPPING_COST, total_price=total_price)
    return "Product niet gevonden", 404

@app.route('/pay', methods=['POST'])
def pay():
    product_id = request.form['product_id']
    product = next((p for p in products if p['id'] == int(product_id)), None)
    if product:
        total_price = product['price'] + SHIPPING_COST
        # In a real application, you would process the payment here.
        # For now, we'll just show a success page.
        return render_template('payment_success.html', product=product, total_price=total_price)
    return "Product niet gevonden", 404

if __name__ == '__main__':
    app.run(debug=True)
