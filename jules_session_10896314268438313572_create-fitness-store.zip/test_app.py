import unittest
from app import app

class AppTestCase(unittest.TestCase):
    def setUp(self):
        self.ctx = app.app_context()
        self.ctx.push()
        self.client = app.test_client()

    def tearDown(self):
        self.ctx.pop()

    def test_home_page(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_products_page(self):
        response = self.client.get('/products')
        self.assertEqual(response.status_code, 200)

    def test_checkout_page(self):
        response = self.client.get('/checkout/1')
        self.assertEqual(response.status_code, 200)

    def test_checkout_page_not_found(self):
        response = self.client.get('/checkout/99')
        self.assertEqual(response.status_code, 404)

    def test_pay_post(self):
        response = self.client.post('/pay', data={'product_id': '1'})
        self.assertEqual(response.status_code, 200)

    def test_pay_get_not_allowed(self):
        response = self.client.get('/pay')
        self.assertEqual(response.status_code, 405)

if __name__ == '__main__':
    unittest.main()
